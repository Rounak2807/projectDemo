package com.byteWheel.controller;

import java.sql.Date;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.ws.rs.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.byteWheel.entity.BookingEntity;
import com.byteWheel.services.BookingService;

@RestController
@Path("/booking")
public class BookingController {

	@Autowired
	BookingService bookingService;

	@RequestMapping(value = "/findById/{Id}/{toDate}", method = RequestMethod.GET, headers = "Accept=application/json")
	public BookingEntity findById(@RequestBody Long id, @RequestBody Date toDate) {
		return bookingService.findById(id, toDate);

	}


	@RequestMapping(value = "/save", method = RequestMethod.POST, headers = "Accept=application/json")
	public void saveBooking(@RequestBody BookingEntity bo) throws SecurityException, RollbackException, HeuristicMixedException,
			HeuristicRollbackException, SystemException {
		bookingService.saveBooking(bo);

	}
	
}
