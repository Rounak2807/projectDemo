package com.byteWheel.services;

import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.byteWheel.dao.CarDAO;
import com.byteWheel.entity.CarEntity;
@Service("carService")
public class CarServiceImpl implements CarService {
   
	@Autowired
	CarDAO carDAO;
	
	@Override
	public void saveCar(CarEntity car) throws SecurityException, RollbackException, HeuristicMixedException, HeuristicRollbackException, SystemException {
		carDAO.saveCar(car); 
	}

	@Override
	public CarEntity findByCarID(Long carId) {
	 
		return carDAO.findByCarID(carId);
	}

	@Override
	public List<CarEntity> findByCategoryID(Long ctegoryId) {
	 
		return carDAO.findByCategoryID(ctegoryId);
	}

	

}
