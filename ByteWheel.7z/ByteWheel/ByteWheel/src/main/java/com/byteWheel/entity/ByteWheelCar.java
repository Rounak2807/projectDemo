package com.byteWheel.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="byteWheelCar")
public class ByteWheelCar {
	@Id
	@Column(name="CAR_ID")
	private int carId;
	@Column(name="CAR_NAME")
    private String carName;
	@Column(name="CATEGORY_ID")
	@ManyToOne
	private ByteWheelCategory byteWheelCategory;
    
	public int getCarId() {
		return carId;
	}
	public void setCarId(int carId) {
		this.carId = carId;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public ByteWheelCategory getByteWheelCategory() {
		return byteWheelCategory;
	}
	public void setByteWheelCategory(ByteWheelCategory byteWheelCategory) {
		this.byteWheelCategory = byteWheelCategory;
	}
    
    
    
	
	

}
