package com.byteWheel.services;

import com.byteWheel.entity.CategoryEntity;

public interface CategoryService {
     
	
	void saveCategory(CategoryEntity category);

	CategoryEntity findCategoryById(Long id);
}
