package com.byteWheel.dao;

import java.sql.Date;

import com.byteWheel.entity.BookingEntity;

public interface BookingDAO {
void saveBooking(BookingEntity booking);
BookingEntity findById(Long id, Date toDate);
}
