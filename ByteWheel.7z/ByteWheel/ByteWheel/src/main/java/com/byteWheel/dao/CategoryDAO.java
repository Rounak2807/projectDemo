package com.byteWheel.dao;

import com.byteWheel.entity.CategoryEntity;

public interface CategoryDAO {
	void saveCategory(CategoryEntity category);

	CategoryEntity findCategoryById(Long id);
}
