package com.byteWheel.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.byteWheel.entity.CategoryEntity;


@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO {
	
	@Autowired
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}


	@Override
	public void saveCategory(CategoryEntity category) {
		Session openSession = sessionFactory.openSession();
		Transaction beginTransaction = openSession.beginTransaction();
		openSession.save(category);
		beginTransaction.commit();
		openSession.flush();
	}

	@Override
	public CategoryEntity findCategoryById(Long id) {
		Session openSession = sessionFactory.openSession();
		return (CategoryEntity)(openSession.get(CategoryEntity.class, id));
	}

}
