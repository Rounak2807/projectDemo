package com.byteWheel.dao;

import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.transaction.Transaction;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.byteWheel.entity.CarEntity;
 
 
 
@Repository("carDAO")
public class CarDAOImpl implements CarDAO {
   
	
	@Autowired
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
	
	@Override
	public void saveCar(CarEntity car) throws  RollbackException, HeuristicMixedException, HeuristicRollbackException, SystemException {
		Session session = sessionFactory.openSession();
	 
		Transaction transaction =  (Transaction) session.beginTransaction();
		session.save(car);
		transaction.commit();
		session.flush();

	}

	@Override
	public CarEntity findByCarID(Long carId) {
		Session session = sessionFactory.getCurrentSession();
		return (CarEntity) session.get(CarEntity.class, carId);
	}

	@Override
	public List<CarEntity> findByCategoryID(Long categoryId) {
		Session session = this.sessionFactory.getCurrentSession();
	       List<CarEntity> list = (List<CarEntity>)(session.createCriteria(CarEntity.class).add(Restrictions.eq("categoryEntity.id", categoryId)).list());
	       return list;
	}

	

}
