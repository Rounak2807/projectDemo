package com.byteWheel.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
 
@Entity
@Table(name="byetwheelCarCategory")
public class CategoryEntity {
	
	@Id
	@Column(name="CATEGORY_ID")
	private int id;
	@Column(name="CATEGORY_NAME")
	private String categoryName;
	@Column(name="CATEGORYRATE")
	private double rate;
	
	@OneToMany(cascade=CascadeType.ALL,mappedBy="byteWheelCategory")
	private List<CarEntity> byteWheelCars;
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public double getRate() {
		return rate;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	
	
	
	

}
