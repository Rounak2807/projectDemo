package com.byteWheel.controller;

import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.ws.rs.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.byteWheel.entity.CarEntity;
import com.byteWheel.services.CarService;

@RestController
@Path("/car")
public class CarController {

	@Autowired
	CarService carService;

	@RequestMapping(value = "/car/findByCarId/{carId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public CarEntity findByCarId(@RequestBody Long carId) {
		return carService.findByCarID(carId);

	}


	@RequestMapping(value = "/car/save", method = RequestMethod.POST, headers = "Accept=application/json")
	public void saveCar(@RequestBody CarEntity bo) throws SecurityException, RollbackException, HeuristicMixedException,
			HeuristicRollbackException, SystemException {
		carService.saveCar(bo);

	}

	@RequestMapping(value = "/car/findBycategoryId/{categoryId}", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<CarEntity> findByCategoryID(@RequestBody Long categoryId) {
		return carService.findByCategoryID(categoryId);

	}

}
