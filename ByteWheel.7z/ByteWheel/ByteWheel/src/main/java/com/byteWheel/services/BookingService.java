package com.byteWheel.services;

import java.sql.Date;

import com.byteWheel.entity.BookingEntity;

public interface BookingService {


	void saveBooking(BookingEntity booking);
	BookingEntity findById(Long id, Date toDate);

}
