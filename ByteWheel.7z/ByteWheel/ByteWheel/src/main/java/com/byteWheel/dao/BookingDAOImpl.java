package com.byteWheel.dao;

import java.sql.Date;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.byteWheel.entity.BookingEntity;

@Repository("bookingDAO")
public class BookingDAOImpl implements BookingDAO {
	@Autowired
	SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void saveBooking(BookingEntity booking) {
		Session openSession = sessionFactory.openSession();
		Transaction beginTransaction = openSession.beginTransaction();
		openSession.save(booking);
		beginTransaction.commit();
		openSession.flush();

	}

	@Override
	public BookingEntity findById(Long id, Date date) {
		Session openSession = sessionFactory.openSession();
		Criteria createCriteria = openSession.createCriteria(BookingEntity.class);
		Criterion booking = Restrictions.eq("booking_id", id);
		Criterion issueDate = Restrictions.ge("car_issue_date", date);
		return (BookingEntity)(createCriteria.add(Restrictions.and(booking, issueDate)).list());
		
		
		
	}

}
