package com.byteWheel.services;

import java.util.List;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;

import com.byteWheel.entity.CarEntity;

public interface CarService {
	
	void saveCar(CarEntity car)throws SecurityException, RollbackException, HeuristicMixedException, HeuristicRollbackException, SystemException;
	CarEntity findByCarID(Long carId);
	List<CarEntity> findByCategoryID(Long ctegoryId);

}
