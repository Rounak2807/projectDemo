package com.byteWheel.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.byteWheel.dao.CategoryDAO;
import com.byteWheel.entity.CategoryEntity;

@Service("categoryService")
public class CategoryServiceImpl implements CategoryService {

	
	@Autowired
	CategoryDAO categoryDao;
	@Override
	public void saveCategory(CategoryEntity category) {
         categoryDao.saveCategory(category);
	}

	@Override
	public CategoryEntity findCategoryById(Long id) {
		
		return categoryDao.findCategoryById(id);
	}

}
