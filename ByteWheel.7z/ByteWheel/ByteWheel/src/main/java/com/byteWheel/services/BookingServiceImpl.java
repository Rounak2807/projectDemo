package com.byteWheel.services;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.byteWheel.dao.BookingDAO;
import com.byteWheel.entity.BookingEntity;
@Service("bookingService")
public class BookingServiceImpl implements BookingService {
	
	@Autowired
	BookingDAO bookingDAO;

	@Override
	public void saveBooking(BookingEntity booking) {
		bookingDAO.saveBooking(booking);
	}

	@Override
	public BookingEntity findById(Long id, Date toDate) {
		return bookingDAO.findById(id, toDate);
	}

}
