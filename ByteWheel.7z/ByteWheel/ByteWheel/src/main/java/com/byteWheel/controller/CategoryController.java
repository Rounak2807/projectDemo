package com.byteWheel.controller;

import javax.transaction.HeuristicMixedException;
import javax.transaction.HeuristicRollbackException;
import javax.transaction.RollbackException;
import javax.transaction.SystemException;
import javax.ws.rs.Path;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.byteWheel.entity.CategoryEntity;
import com.byteWheel.services.CategoryService;

@RestController
@Path("/category")
public class CategoryController {
	@Autowired
	CategoryService categoryService;

	@RequestMapping(value = "/findById/{Id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public CategoryEntity findById(@RequestBody Long id) {
		return categoryService.findCategoryById(id);

	}


	@RequestMapping(value = "/save", method = RequestMethod.POST, headers = "Accept=application/json")
	public void saveCar(@RequestBody CategoryEntity bo) throws SecurityException, RollbackException, HeuristicMixedException,
			HeuristicRollbackException, SystemException {
		categoryService.saveCategory(bo);

	}
}
